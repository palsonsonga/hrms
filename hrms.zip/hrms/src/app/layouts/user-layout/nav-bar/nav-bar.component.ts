import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public toggleMenu(): void {
    if (document.body.classList.contains('show-menu')) {
      document.body.classList.remove('show-menu');
    } else {
      document.body.classList.add('show-menu');
    }
    if (window.innerWidth <= 800) {
      if (document.body.classList.contains('stage-menu-open')) {
        document.body.classList.remove('stage-menu-open')
      }
    }
  }
}
