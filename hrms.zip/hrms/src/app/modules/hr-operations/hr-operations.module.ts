import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HrOperationsRoutingModule } from './hr-operations-routing.module';
import { CompanyModule } from './company/company.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HrOperationsRoutingModule,
    CompanyModule
  ]
})
export class HrOperationsModule { }
