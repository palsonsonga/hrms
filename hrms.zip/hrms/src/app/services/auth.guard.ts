import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalStorageService } from '../util/local-storage.service';
import { AuthenticationService } from './authentication.service';
/**
 * @description AuthGaurd used for authentication of user routing
 * @name Swetha Patlola
 */
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  
  constructor(private _service: AuthenticationService, private _ls: LocalStorageService){}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      // authenticating : user session exists or not
      if(this._ls.isLoggedIn()){
        // user session exists
        return true;
      }else{
        // TODO :  return to login page here
      }
    return true;
  }
  
}
