import { HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LocalStorageService } from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {
  constructor(private _ls: LocalStorageService, private _router: Router) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let currentUser = localStorage.getItem('currentUser');
    console.log(currentUser);
      if (currentUser!=null) {
        if(JSON.parse(currentUser).token){
          req = req.clone({
            setHeaders: {
                Authorization: "Bearer " + this._ls.getLoggedInUser("currentUser",true).token,
                'content-type': 'application/json',
                'Access-Control-Allow-Origin':'*'
            }
          });
        }
      }
      return next.handle(req);
  }
}
