const mongoose= require('mongoose');
const schema=mongoose.Schema;
const countrySchema=new schema({
    checked:{type:Boolean,required:true},
    country:{type:String,required:true},
    details:{type:String,required:true}
})


module.exports=mongoose.model('country',countrySchema)//users collections