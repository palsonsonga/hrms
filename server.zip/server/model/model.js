const mongoose= require('mongoose');
const schema=mongoose.Schema;
const userSchema=new schema({
    title:{type:String,required:true},
    content:{type:String,required:true},
    gender:{type:String,required:true}
})


module.exports=mongoose.model('Model',userSchema)//users collections