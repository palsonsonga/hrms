const jwt=require('jsonwebtoken');

module.exports=(req,res,next)=>{
    try{
        //spliting authorization 'Bearer token'
       const token = req.headers.authorization.split(" ")[1];
       //verifying the token
       jwt.verify(token,'secretKey');
       //if token verified we can go to next prosses
       next();
    }
    catch(err){
        res.status(401).send('auth failed' +err);
    }
}