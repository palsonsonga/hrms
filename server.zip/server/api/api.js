const express=require('express')
const mongoose=require('mongoose')
const router=express.Router()
const Post = require("../model/model");
const Country =  require('../model/country')
const bodyParser = require("body-parser");
const checkAuth=require('../middleware/check-auth');
router.use(bodyParser.json());
mongoose
  .connect(
    "mongodb+srv://sam:bayblade@cluster0-coz9c.mongodb.net/user?retryWrites=true&w=majority"  //'mongodb://127.0.0.1:27017/new';

  ,{ useNewUrlParser: true } )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });
  router.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST,PUT, PATCH, DELETE, OPTIONS"
    );
    next();
  });

  router.get('/',(req,res)=>{
      res.send('Router')
  })
  router.post("/user", 
   //checkAuth,//verifying token and protecting the route
  (req, res, next) => {
    const post = new Post(
        req.body
    );
    post.save();
    res.status(201).json({
      message: "Post added successfully"
    });
  });
  
  router.get("/user", (req, res, next) => {
    Post.find().then(doc => {
      res.status(200).json({
        message: "Posts fetched successfully!",
        posts: doc
      });
    });
  });
  
  router.delete("/user/:id", (req, res, next) => {
    Post.deleteOne({ _id: req.params.id }).then(result => {
      console.log(result);
      res.status(200).json({ message: "Post deleted!" });
    });
  });
  router.put("/user/:id", (req, res, next) => {
    const post = new Post({
      _id: req.body.id,
      title: req.body.title,
      content: req.body.content,
      gender:req.body.gender
    });
    Post.updateOne({ _id: req.params.id }, post).then(result => {
      //console.log(result);
      res.status(200).json({ message: "Update successful!" });
    });
  });
  router.get('/',(req,res)=>{
    res.send('Router')
})
router.post("/countrys", 
 //checkAuth,//verifying token and protecting the route
(req, res, next) => {
  const post = new  Country(
      req.body
  );
  post.save();
  res.status(201).json({
    message: "Post added successfully"
  });
});

router.get("/countrys", (req, res, next) => {
  Country.find().then(doc => {
    res.status(200).json({
      message: "Posts fetched successfully!",
      countrys: doc
    });
  });
});

router.delete("/countrys/:id", (req, res, next) => {
  Country.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json({ message: "Post deleted!" });
  });
});
router.put("/countrys/:id", (req, res, next) => {
  const post = new  Country({
    _id: req.body.id,
    checked: req.body.checked,
    country: req.body.country,
   details:req.body.details
  });
  Country.updateOne({ _id: req.params.id }, post).then(result => {
    //console.log(result);
    res.status(200).json({ message: "Update successful!" });
  });
});




  module.exports=router