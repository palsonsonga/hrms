'use strict';
const express=require('express');
const bodyParser=require ('body-parser');
const cors= require('cors');
const app=new express();
const jwt=require('jsonwebtoken');
const port=3000;
const checkAuth=require('./middleware/check-auth');
const api=require('./api/api');
const Model=require('./model/model');
const Log=require('./model/log')
const reg=require('./model/reg')
const mongoose=require('mongoose');
const { findOne } = require('./model/model');

app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({extended:false}))
//app.use(cors());
//mongoose.set({ useUnifiedTopology: true })
mongoose
  .connect(
    "mongodb+srv://sam:bayblade@cluster0-coz9c.mongodb.net/user?retryWrites=true&w=majority"  //'mongodb://127.0.0.1:27017/new';

  ,{ useNewUrlParser: true } )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST,PUT, PATCH, DELETE, OPTIONS"
    );
    next();
  });

app.use('/api',api);
//app.use('/',reg)
app.post('/register',  (req,res)=>{
    const reg1=new reg(
        req.body
    );
    reg.findOne({email:reg1.email},(err,data)=>{
        if(data){
            res.status(401).json('invalid mail')
        }
        else{
            reg1.save(
                (err,regDetails)=>{
                    if(err){
                        console.log(err)
                    }
                    else{
                    let payload={subject:regDetails._id}
                    let token =jwt.sign(payload,'secretKey')
                    res.status(201).send({token})
                }
            })
            }
    })
 
})
app.get('/register',(req,res)=>{
    reg.find().then(
       (doc=>{
        res.status(200).json({message:'successfully received',  details:doc})
    }))
})

app.put('/register/:id',(req,res)=>{
    reg1=new reg({
        _id:req.body.id,
        userName:req.body.userName,
        email:req.body.email,
        password:req.body.password
    })
    reg.updateOne({_id:req.params.id},reg1).then(
        res.status(200).json({message:'updated'})
    )
})
app.delete('/register/:id',(req,res)=>{
   reg.deleteOne({_id:req.params.id}).then(
       res.status(200).json({ message:'deleted'})
   ).catch(err=>{
       console.log(err)
   })
})
app.post('/login',(req,res)=>{
const log=new Log(req.body)
reg.findOne({email:log.email},(err,data)=>{
    if(err){
        console.log(err)
    }
    else if(!data){
        res.status(401).send('invalid mail')
    }
    else if(data.password!==log.password){
        res.status(401).json({ message:'invalid password'})
    }
    else{
        let payload={subject:data._id}
        let token =jwt.sign(payload,'secretKey',{expiresIn:'360.0166666h'})
        res.status(200).json({token,expiresIn:60})
    }
})

})



module.exports = app;

app.listen(port,()=> 
    console.log('server working on localhost:'+port)
    )
   
